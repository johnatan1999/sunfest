<?php
	class Admin extends CI_Controller {
		
		public function index() {
			return redirect()->to('index_');
		}
		
		public function inserer_artiste() {
			$this->load->model('Artiste');
			$login = $this->input->post('login');
			$mdp = $this->input->post('mdp');
			$nom = $this->input->post('nom');
			// $pdp = $this->input->post('pdp');
			$pdp = $this->upload('pdp', $login);
			$data['artistes'] = $this->Artiste->inserer($login, $mdp, $nom, $pdp);
			// $this->index();
		}
		
		public function modifier_artiste() {
			$this->load->model('Artiste');
			$login = $this->input->post('login');
			$ancien_mdp = $this->input->post('ancien_mdp');
			$mdp = $this->input->post('mdp');
			$nom = $this->input->post('nom');
			// $pdp = $this->input->post('pdp');
			$data['artistes'] = $this->Artiste->modifier($login, $ancien_mdp, $mdp, $nom, $pdp);
			$this->index();
		}
	
		private function upload($field_name, $file_name) {
			$config['upload_path'] = './assets/images/avatars';
			$config['allowed_types'] = 'gif|png|jpg|jpeg';
			$config['file_name'] = $file_name;
			// $config['max_size'] = 300;
			$config['max_width'] = 2000;
			$config['max_height'] = 2000;
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			if( ! $this->upload->do_upload($field_name)) {
				$error = array('error' => $this->upload->display_errors());
				$this->load->view('resultat', $error);
			} else {
				// $data = array(
					// 'upload_data' => $this->upload->data(),
					// 'page' => 'resultat'
				// );
				// $this->load->view('resultat', $data);
				$d = $this->upload->data();
				return $d['file_name'];
			}
		}
	
	}
;?>