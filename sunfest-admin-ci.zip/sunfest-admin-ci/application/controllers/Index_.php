<?php
	class Index_ extends CI_Controller {
		
		public function index() {
			session_start();
			if( ! isset($_SESSION['admin'])) {
				return redirect('index_/login');
			}
			$this->load->model('Artiste');
			$data['page'] = 'artistes';
			$data['artistes'] = $this->Artiste->get_artistes();
			$this->load->view('index', $data);
		}
		
		public function login() {
			$this->load->view('login');
		}
		

	}
;?>