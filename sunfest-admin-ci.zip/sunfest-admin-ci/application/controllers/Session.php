<?php
	
	class Session extends CI_Controller {
		
		
		public function authentifier() {
			session_start();	
			$this->load->model('Administrateur');
			$login = $this->input->post('login');
			$mdp = $this->input->post('mdp');
			$admin = $this->Administrateur->authentifier($login, $mdp);
			if( ! empty($admin)) {
				$_SESSION['admin'] = $admin;
				
				redirect('admin');
			} else {
				var_dump($admin);
				redirect('index_/login');
			}
				
		}
		
		public function logout() {
			session_start();
			session_unset();
			session_destroy();
			redirect('index_');
		}
		
	}

?>