<?php
	
	class Administrateur extends CI_Model {
		
		public function authentifier($login, $mdp) {
			$a = $this->db->query("select * from admin_ where login_admin = '$login' and mdp_admin = '$mdp'");
			$a = $a->row_array();
			return $a;
		}
		
		
	}

?>