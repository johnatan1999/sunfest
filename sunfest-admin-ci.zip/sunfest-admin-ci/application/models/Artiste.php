<?php 

	class Artiste extends CI_model {
	
		public function get_artistes() {
			$a = $this->db->query("select * from artiste");
			return $a;
		}
		
		public function inserer($login, $mdp, $nom, $pdp) {
			$this->db->set('login_artiste',   $login);
			$this->db->set('mdp_artiste', $mdp);
			$this->db->set('nom_artiste', $nom);
			$this->db->set('date_inscription', 'now()', false);	
			$this->db->set('image_profil', $pdp);	
			return $this->db->insert('Artiste');
		}
			
		
		public function modifier($login, $ancien_mdp, $mdp, $nom, $pdp) {
			$data = array(
				'mdp_artiste' => $mdp,
				'nom_artiste' => $nom,
				'image_profil' => $pdp
			);
			echo $mdp;
			$this->db->where('login_artiste', $login);
			$this->db->where('mdp_artiste', $ancien_mdp);
			$this->db->update("artiste", $data);
		}

	}

?>