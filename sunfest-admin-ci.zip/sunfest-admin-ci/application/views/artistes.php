<div>

	<table class="table table-hover">
		<tr>
			<th>Profil</th>
			<th>Login</th>
			<th>Mot de passe</th>
			<th>Nom</th>
			<th>Date d' inscription</th>
			<th>-</th>
		</tr>
		<?php foreach($artistes->result_array() as $a) {;?>
		<form method="POST" action="<?php echo site_url('admin/modifier_artiste') ;?>">
		<tr>
			<!--<td><input type="text" name="login" value="<?php //echo $a['login_artiste']; ?>"></td>-->
			<input type="text" name="login" value="<?php echo $a['login_artiste']; ?>" hidden>
			<input type="text" name="ancien_mdp" value="<?php echo $a['mdp_artiste']; ?>" hidden>
			
			<td><img width='75' src="<?php echo pdp_url($a['image_profil']); ?>" alt="Profil"/><input type="file" name="pdp" placeholder="Profil"/></td>
			<td><?php echo $a['login_artiste']; ?></td>
			<td><input class="form-control" type="text" name="mdp" value="<?php echo $a['mdp_artiste']; ?>"></td>
			<td><input class="form-control" type="text" name="nom" value="<?php echo $a['nom_artiste']; ?>"></td>
			<td><?php echo $a['date_inscription']; ?></td>
			<td><a href="<?php echo site_url('admin/remove_artiste') ?>" class="btn btn-danger">Delete</a></td>
			<td></i><input type="submit" class="btn btn-warning" value="Modifier"/></td>
		</tr>
		</form>
		<?php };?>
		<form method="POST" action="<?php echo site_url('admin/inserer_artiste') ;?>" enctype="multipart/form-data">
		<tr>
			<td><input type="file" name="pdp" placeholder="Profil"/></td>
			<td><input class="form-control" type="text" name="login" placeholder="Login"/></td>
			<td><input class="form-control" type="text" name="mdp" placeholder="Mdp"/></td>
			<td><input class="form-control" type="text" name="nom" placeholder="Nom"/></td>
			<td></td>
			<td><input type="submit" class="btn btn-success" value="Ajouter"/></td>
		</tr>
		</form>
	</table>

</div>