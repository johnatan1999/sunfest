<!DOCTYPE html>
<!--
* CoreUI - Free Bootstrap Admin Template
* @version v2.1.8
* @link https://coreui.io
* Copyright (c) 2018 creativeLabs Łukasz Holeczek
* Licensed under MIT (https://coreui.io/license)
-->

<html lang="en">
  <head>
    <base href="./">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta name="description" content="CoreUI - Open Source Bootstrap Admin Template">
    <meta name="author" content="Łukasz Holeczek">
    <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,jQuery,CSS,HTML,RWD,Dashboard">
    <title>Sunfest Admin</title>

    <!-- Main styles for this application-->
    <link href="<?php echo css_url('style') ?>" rel="stylesheet">
    <link href="<?php echo css_url('pace.min') ?>" rel="stylesheet">
    <!-- Global site tag (gtag.js) - Google Analytics-->
    <script>
      window.dataLayer = window.dataLayer || [];

      function gtag() {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
      // Shared ID
      gtag('config', 'UA-118965717-3');
      // Bootstrap ID
      gtag('config', 'UA-118965717-5');
    </script>
  </head>
  <body class="app flex-row align-items-center" style="background-color: #000">
    <div class="container" style="height: 540px; background: url(<?php echo img_url('2.jpg') ?>)">
      <div class="row justify-content-center">
        <div class="col-md-6" style="margin-top: 7%;">
          <div class="card-group">
            <div class="card p-4">
              <div class="card-body" style="background-color: #ddd">
                <h1>Login</h1>
                <p class="text-muted">Sign In to your account</p>
				<form action="<?php echo site_url('session/authentifier') ?>" method="post">
					<div class="input-group mb-3">
					  <div class="input-group-prepend">
						<span class="input-group-text">
						  <i class="icon-user"></i>
						</span>
					  </div>
					  <input class="form-control" name="login" value="za@gmail.com"  type="text" placeholder="Username">
					</div>
					<div class="input-group mb-4">
					  <div class="input-group-prepend">
						<span class="input-group-text">
						  <i class="icon-lock"></i>
						</span>
					  </div>
					  <input class="form-control" name="mdp" value="Za1999"  type="password" placeholder="Password">
					</div>
					<div class="row">
					  <div class="col-6">
						<button type="submit" class="btn btn-primary px-4">Login</button>
					  </div>
					  <div class="col-6 text-right">
					  </div>
					</div>
				</form> 
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>

  </body>
</html>
