/*==============================================================*/
/* nom de sgbd :  mysql 5.0                                     */
/* date de cr�ation :  05/05/2019 09:08:55                      */
/*==============================================================*/
drop database if exists sunfest;

create database sunfest;

use sunfest;
 
drop table if exists admin_;

drop table if exists artiste;

drop table if exists evenement;

/*==============================================================*/
/* table : admin_                                               */
/*==============================================================*/
create table admin_
(
   login_admin          varchar(30) not null,
   mdp_admin            varchar(30) not null,
   nom_admin            varchar(20) not null,
   primary key (login_admin, mdp_admin)
);

/*==============================================================*/
/* table : artiste                                              */
/*==============================================================*/
create table artiste
(
   idartiste            int not null auto_increment,
   login_artiste        varchar(30) not null,
   mdp_artiste          varchar(30) not null,
   nom_artiste          varchar(30),
   date_inscription     date not null,
   image_profil         varchar(250),
   retire               bool,
   primary key (idartiste)
);

/*==============================================================*/
/* table : evenement                                            */
/*==============================================================*/
create table evenement
(
   idevenement          int not null auto_increment,
   idartiste            int,
   description          text,
   lieu                 varchar(20) not null,
   date_evenement       datetime not null,
   nombre_ticket        int not null,
   image                varchar(250),
   primary key (idevenement)
);

alter table evenement add constraint fk_relation_1 foreign key (idartiste)
      references artiste (idartiste) on delete restrict on update restrict;

insert into admin_ values('za@gmail.com', 'Za1999', 'ADMIN');

insert into artiste values(null,'bolo','pix','Bolo Pix','2019-05-04', 'bolo.png', 0);
insert into artiste values(null,'damian','marley','Damian Marley','0000-00-00', 'damian.png', 0);
insert into artiste values(null,'ra','force','Ra Force','2019-05-04', 'ra.png', 0);
insert into artiste values(null,'ramora','favoris','Ramora Favoris','2019-05-04', 'ramora.png', 0);
insert into artiste values(null,'jamie','scott','Jamie Scott','2019-05-04', 'jamie.png', 0);
insert into artiste values(null,'skip','marley','Skip Marley','2019-05-04', 'skip.png', 0);
insert into artiste values(null,'stephen','marley','Stephen Marley','2019-05-04', 'stephen.png', 0);
insert into artiste values(null,'dj','nicky','DJ Nicky','2019-05-04', 'DJ.png', 0);
insert into artiste values(null,'nicky','dj','Nicky DJ','2019-05-04', 'Nicky.png', 0);
