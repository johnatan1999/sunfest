<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class Event_ extends CI_Controller {
		
		public function __construct() {
			CI_Controller::__construct();
			$this->load->model('Event');
			session_start();
			if( ! isset($_SESSION['artiste'])) {
				return redirect('/');
			}  
		}
		
		public function index() {
			// session_start();
			$data['events'] = $this->Event->get_events_($_SESSION['artiste']['idartiste'], 0, 10);
			$data['page'] = 'event-admin';
			$this->load->view('index', $data);
		}
		
		public function export() {
			$data = $this->Event->get_artiste();
			foreach($data->result_array() as $d) {
				echo "insert into artiste values(null, '".$d['idartiste']."','".$d['login_artiste']."','".$d['mdp_artiste']."','".$d['nom_artiste']."','".$d['date_inscription']."','".$d['retire']."','".$d['image_profil']."')<br>";
			}
		}
		
		public function inserer() {
			$ida = $this->input->post('idartiste');
			$lieu = $this->input->post('lieu');
			$desc = $this->input->post('desc');
			$ticket = $this->input->post('ticket');
			$date = $this->input->post('date');
			$img = $this->input->post('image');
			$this->Event->inserer($ida, $desc, $lieu, $date, $ticket, $img);
			// admin = event_/index
			return redirect('admin');
		}
		
	}
;?>