<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Index_ extends CI_Controller {
		
		public function __construct() {
			CI_Controller::__construct();
			$this->load->model('Artiste');
			$this->load->model('Event');
			session_start();
		}
		
		public function index() {
			$data['artistes'] = $this->Artiste->get_artistes(1, 3);
			$data['events'] = $this->Event->get_events(0, 10);
			$this->load->view('index', $data);
		}
		
		public function artistes($page='1') {
			$data['page'] = 'artistes';
			$data['artistes'] = $this->Artiste->get_artistes($page, 10);
			$this->load->view('index', $data);
		}
		
		public function events($page='1') {
			$data['page'] = 'event';
			$data['events'] = $this->Event->get_events($page, 10);
			$this->load->view('index', $data);
		}
		
		public function event($idevent) {
			$data['page'] = 'event-single';
			$data['event'] = $this->Event->get_event($idevent);
			// var_dump($data['event']);
			$this->load->view('index', $data);
		}
		
		public function login() {
			// session_start();
			if(isset($_SESSION['artiste'])) {
				return redirect('admin');
			}  
			$this->load->view('login');
		}
		
		public function register() {
			if(isset($_SESSION['artiste'])) {
				return redirect('admin');
			}  
			$this->load->view('register');
		}
		
	}
;?>