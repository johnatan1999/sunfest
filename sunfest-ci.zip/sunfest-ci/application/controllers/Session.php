<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class Session extends CI_Controller {
		
		public function __construct() {
			CI_Controller::__construct();
			$this->load->model('Artiste');
		}
		
		public function index() {
		}
		
		public function logout() {
			session_start();
			session_unset();
			session_destroy();
			// / = index_/index
			return redirect('/');
		}
		
		public function login() {
			session_start();
			$user = $this->input->post('username');
			$mdp = $this->input->post('password');
			$artiste = $this->Artiste->authentifier($user, $mdp);
			if( empty($artiste)){
				$error['error'] = 'Invalid username or password';
				$this->load->view('login', $error);
			} else {
				$_SESSION['artiste'] = $artiste; 
				// admin = event_/index
				return redirect('admin');
			}
		}
		
		
		public function register() {
			$username = $this->input->post('username');
			$artist_name = $this->input->post('username');
			$mdp = $this->input->post('password');
			$mdp2 = $this->input->post('confirmation');
			$this->Artiste->inserer($username, $mdp, $artist_name, 'default.png');
			// login = index_/login 
			return redirect('login');
		}
		
 	} 
?>