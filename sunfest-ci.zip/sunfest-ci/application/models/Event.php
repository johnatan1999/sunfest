<?php 

	class Event extends CI_model {
	
		public function get_events($nb, $page) {
			$e = $this->db->query("select * from evenement join artiste on evenement.idartiste = artiste.idartiste where date_evenement > now() order by date_evenement desc limit $nb, $page ");			
			return $e;
		}
		
		public function get_events_($idartiste, $nb, $page) {
			$e = $this->db->query("select * from evenement join artiste on evenement.idartiste = artiste.idartiste where artiste.idartiste = $idartiste and date_evenement > now() order by date_evenement desc limit $nb, $page ");			
			return $e;
		}

		public function get_event($id) {
			$e = $this->db->query("select * from evenement join artiste on evenement.idartiste = artiste.idartiste where idevenement = $id");
			$e = $e->row_array();
			return $e;
		}
		
		public function get_artiste() {
			$a = $this->db->query("select * from artiste");
			return $a;
		}
		
		public function inserer($idartiste, $desc, $lieu, $date, $ticket, $image) {
			$this->db->set('idartiste',   $idartiste);
			$this->db->set('description', $desc);
			$this->db->set('lieu', $lieu);
			$this->db->set('date_evenement', $date);	
			$this->db->set('nombre_ticket', $ticket);	
			$this->db->set('image', $image);	
			return $this->db->insert('evenement');
		}
		
		public function modifier($idevent, $idartiste, $desc, $lieu, $date, $ticket, $image) {
			$data = array(
				'idartiste'      => $idartiste,
			    'description'    => $desc,
			    'lieu'           => $lieu,
			    'date_evenement' => $date,	
			    'nombre_ticket'  => $ticket,	
			    'image'  => $image
			);
			$this->db->where('idevenement', $idevenement);
			$this->db->update("evenement", $data);
		}

	}

?>