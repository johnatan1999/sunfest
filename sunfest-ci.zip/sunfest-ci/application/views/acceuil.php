<div class="content-section">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="lineup-artists-headline">
					<div class="entry-title">
						<p>JUST THE BEST</p>
						<h2>The Lineup Artists-Headliners</h2>
					</div><!-- entry-title -->

					<div class="lineup-artists">
						<?php $index = 0;foreach($artistes->result_array() as $artiste) {?>	
							<?php if($index % 2 == 0) {?>
								<div class="lineup-artists-wrap flex flex-wrap">
									<figure class="featured-image">
										<a href="#"> <img src="<?php echo pdp_url($artiste['image_profil']) ?>" alt=""> </a>
									</figure><!-- featured-image -->

									<div class="lineup-artists-description">
										<div class="lineup-artists-description-container">
											<div class="entry-title">
												<?php echo $artiste['nom_artiste'];?>
											</div><!-- entry-title -->

											<div class="entry-content">
												<p>Quisque at erat eu libero consequat tempus. Quisque mole stie convallis tempus. Ut semper purus metus, a euismod sapien sodales ac. Duis viverra eleifend fermentum. </p>
											</div><!-- entry-content -->
										</div><!-- lineup-artists-description-container -->
									</div><!-- lineup-artists-description -->
								</div><!-- lineup-artists-wrap -->
							<?php } else {?>
							<div class="lineup-artists-wrap flex flex-wrap">
								<div class="lineup-artists-description">
									<figure class="featured-image d-md-none">
										<a href="#"> <img src="<?php echo pdp_url($artiste['image_profil']) ?>" alt=""> </a>
									</figure><!-- featured-image -->
									<div class="lineup-artists-description-container">
										<div class="entry-title">
											<?php echo $artiste['nom_artiste'];?>
										</div><!-- entry-title -->

										<div class="entry-content">
											<p>Quisque at erat eu libero consequat tempus. Quisque mole stie convallis tempus. Ut semper purus metus, a euismod sapien sodales ac. Duis viverra eleifend fermentum. </p>
										</div><!-- entry-content -->
									</div><!-- lineup-artists-description-container -->
								</div><!-- lineup-artists-description -->

								<figure class="featured-image d-none d-md-block">
									<a href="#"> <img src="<?php echo pdp_url($artiste['image_profil']) ?>" alt=""> </a>
								</figure><!-- featured-image -->
							</div><!-- lineup-artists-wrap -->
							<?php }$index += 1;?>
						<?php }?>
					</div><!-- lineup-artists -->
				</div><!-- lineup-artists-headline -->
			</div><!-- col-12 -->
		</div><!-- row -->

	</div><!-- container -->

	<div class="homepage-next-events">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="entry-title">
						<p>JUST THE BEST</p>
						<h2>Our Next Events</h2>
					</div><!-- entry-title -->
				</div><!-- col-12 -->
			</div><!-- row -->
		</div><!-- container -->

		<div class="next-event-slider-wrap">
			<div class="swiper-container next-event-slider">
				<div class="swiper-wrapper">
					<?php foreach($events->result_array() as $event) {?>
					<div class="swiper-slide">
						<div class="next-event-content">
							<figure class="featured-image">
								<img src="<?php echo img_url($event['image']) ;?>" alt="">

								<a href="<?php echo site_url('index_/event/'.$event['idevenement']) ?>" class="entry-content flex flex-column justify-content-center align-items-center">
									<h3><?php echo $event['description'].' avec '.$event['nom_artiste'] ?></h3>
									<p><?php echo $event['date_evenement'].', '.$event['lieu'] ?></p>
								</a>
							</figure><!-- featured-image -->
						</div><!-- next-event-content -->
					</div><!-- swiper-slide" -->
					<?php }?>
				</div><!-- .swiper-wrapper -->
			</div><!-- .swiper-container -->

			<div class="swiper-button-next">
				<img src="<?php echo img_url('button.png') ?>" alt="">
			</div><!-- .slider-button -->
		</div><!-- .next-event-slider-wrap -->
	</div><!-- homepage-next-events -->

</div>