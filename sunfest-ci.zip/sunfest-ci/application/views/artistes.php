
<div class="content-section">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="lineup-artists-headline">
					<div class="entry-title">
						<h2>Artistes</h2>
					</div><!-- entry-title -->

					<div class="lineup-artists">
						<?php $index = 0; foreach($artistes->result_array() as $artiste) { ;?>	
							<?php if($index % 2 == 0) {?>
							<div style="margin-bottom: 2%">
								<div class="row">
									<div class="col-md-3" style="background-color: #e9e9e9; padding: 2% 2% 2% 5%">
										<a href="#"> <img width="200" src="<?php echo pdp_url($artiste['image_profil']) ?>" alt=""> </a>
									</div>
									<div class="col-md-6" style="background-color: #e9e9e9; padding: 2%">
										<div class="entry-title" style="color: #aaaaaa">
											<h3 style="color: #666666"><?php echo $artiste['nom_artiste'];?></h3>
										</div>
										<div class="entry-content" style="color: #aaaaaa">
											<p>Quisque at erat eu libero consequat tempus. Quisque mole stie convallis tempus. Ut semper purus metus, a euismod sapien sodales ac. Duis viverra eleifend fermentum. </p>
										</div>										
									</div>
								</div>
							</div>
							<?php } else { ;?>
							<div style="margin-bottom: 2%">
								<div class="row">
									<div class="col-md-3"></div>
									<div class="col-md-offset-1 col-md-6" style="background-color: #e9e9e9; padding: 2%">
										<div class="entry-title" style="color: #aaaaaa">
											<h3 style="color: #666666"><?php echo $artiste['nom_artiste'];?></h3>
										</div>
										<div class="entry-content" style="color: #aaaaaa">
											<p>Quisque at erat eu libero consequat tempus. Quisque mole stie convallis tempus. Ut semper purus metus, a euismod sapien sodales ac. Duis viverra eleifend fermentum. </p>
										</div>										
									</div>
									<div class="col-md-3" style="background-color: #e9e9e9; padding: 2% 5% 2% 2%">
										<a href="#"> <img width="200" src="<?php echo pdp_url($artiste['image_profil']) ?>" alt=""> </a>
									</div>
								</div>
							</div>
							<?php } $index += 1?>
						<?php }?>
					</div><!-- lineup-artists -->
				</div><!-- lineup-artists-headline -->
			</div><!-- col-12 -->
		</div><!-- row -->

	</div><!-- container -->
</div><!-- container -->

