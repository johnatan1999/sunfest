	
	<div class="blog-page">
	<div class="main-content">
        <div class="container" style="min-height: 500px">
			<table class="table">
				<form action="<?php echo site_url('new_event')?>" method="post">
				<tr>
					<td><textarea type="text" name="desc" placeholder="Description" required></textarea></td>
					<td><input class="form-control" type="text" name="lieu" placeholder="Lieu" required/><input type="text" value="<?php echo $_SESSION['artiste']['idartiste'] ?>" name="idartiste" hidden/></td>
					<td><input class="form-control" type="number" name="ticket" min="0" step="10" placeholder="Ticket" required/></td>
					<td><input class="form-control" type="date" name="date" placeholder="Date" required/></td>
					<td><input class="form-control" type="file" name="image" placeholder="Image" required/></td>
					<td><input class="btn" type="submit" value="Inserer"/></td>
				</tr>
				</form>
			</table>
            <div class="last-news">                
                <div class="row blog-list-page">
					<?php foreach($events->result_array() as $event) { ?> 
                    <div class="col-md-4 col-md-4 single-blog-content">
                        <div class="blog-content">
                            <figure class="featured-image">
                                <a href="#"> <img src="<?php echo img_url($event['image']) ?>" alt="fesival+celebration"> </a>
                            </figure><!-- featured-image -->

                            <div class="box-link-date">
                                <a href=""><?php echo $event['date_evenement']; ?></a>
                            </div><!-- box-link-date -->

                            <div class="entry-content">
                                <div class="entry-header">
                                    <h2><?php echo $event['description']?></h2>
                                </div><!-- entry-header -->

                                <div class="entry-meta">
                                    <span class="author-name"><a href="#">By <?php echo $event['nom_artiste'] ?></a></span>
                                    <span class="space">|</span>
                                    <!--<span class="comments-count"><a href="#">3 comments</a></span>-->
                                </div><!-- entry-meta -->

                                <div class="entry-description">
                                    <p>Quisque at erat eu libero consequat tempus. Quisque mole stie convallis tempus. Ut semper purus metus, a euismod sapien sodales ac. Duis viverra eleifend fermentum.</p>
                                </div><!-- entry-description -->
                            </div><!-- entry-content -->
                        </div>
                    </div><!-- col-6 -->
                    <?php } ?>

                </div><!-- blog-list-page -->
            </div><!-- last-news -->
        </div><!-- container -->
    </div><!-- main-content -->
    </div><!-- main-content -->

