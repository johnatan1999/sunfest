<div class="tickets-page">
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="entry-header">
                        <h2 class="entry-title">Buy tickets</h2>

                        <ul class="breadcrumbs flex align-items-center">
                            <li><a href="#">Home</a></li>
                            <li>Buy tickets</li>
                        </ul><!-- .breadcrumbs -->
                    </div><!-- entry-header -->
                </div><!-- col-12 -->
            </div><!-- row -->
        </div><!-- container -->
    </div><!-- page-header -->

    <div class="main-content">
        <div class="container">
            <div class="entry-header">
                <div class="entry-title">
                    <h2><?php echo $event['nom_artiste'] ?> event</h2>
                </div><!-- entry-title -->
            </div><!-- entry-header -->

            <div class="row">
                <div class="col-12">
                    <div class="tabs">
                        <ul class="tabs-nav flex">
                            <li class="tab-nav flex justify-content-center align-items-center active" data-target="#tab_details">Details</li>
                            <li class="tab-nav flex justify-content-center align-items-center" data-target="#tab_venue">Venue</li>
                            <li class="tab-nav flex justify-content-center align-items-center" data-target="#tab_organizers">Organizers</li>
                            <li class="tab-nav flex justify-content-center align-items-center" data-target="#tab_about">About the event</li>
                        </ul><!-- tabs-nav -->

                        <div class="tabs-container">
                            <div id="tab_details" class="tab-content">
                                <div class="flex flex-wrap justify-content-between">
                                    <div class="single-event-details">
                                        <div class="single-event-details-row">
                                            <label>Start:</label>
                                            <p>June 17 @ 09:00 am</p>
                                        </div>

                                        <div class="single-event-details-row">
                                            <label>End:</label>
                                            <p>June 22 @ 07:30 am</p>
                                        </div>

                                        <div class="single-event-details-row">
                                            <label>Price:</label>
                                            <p class="sold-out">$89 <span>Sold Out</span></p>
                                        </div>

                                        <div class="single-event-details-row">
                                            <label>Categories:</label>
                                            <p>Festivals</p>
                                        </div>

                                        <div class="single-event-details-row">
                                            <label>Tags:</label>
                                            <p><a href="#">festivals</a>, <a href="#">music</a>, <a href="#">concert</a></p>
                                        </div>
                                    </div>

                                    <div class="single-event-map">
                                        <!--<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=university of san francisco&t=&z=15&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
										-->
										<img width="100%" src="<?php echo img_url($event['image'])?>" alt="Event"/>
									</div>
                                </div>
                            </div><!-- .tab-content -->

                            <div id="tab_venue" class="tab-content">
                                <p>Curabitur venenatis efficitur lorem sed tempor. Integer aliquet tempor cursus. Nullam vestibulum convallis risus vel condimentum. Nullam auctor lorem in libero luctus, vel volutpat quam tincidunt. Morbi sodales, dolor id ultricies dictum, diam odio tempor purus, at ultrices elit nulla ac nisl. Vestibulum enim sapien, blandit finibus elit vitae, venenatis tempor enim. </p>
                            </div><!-- .tab-content -->

                            <div id="tab_organizers" class="tab-content">
                                <p>Curabitur venenatis efficitur lorem sed tempor. Integer aliquet tempor cursus. Nullam vestibulum convallis risus vel condimentum. Nullam auctor lorem in libero luctus, vel volutpat quam tincidunt. Morbi sodales, dolor id ultricies dictum, diam odio tempor purus, at ultrices elit nulla ac nisl. Vestibulum enim sapien, blandit finibus elit vitae, venenatis tempor enim. </p>
                            </div><!-- .tab-content -->

                            <div id="tab_about" class="tab-content">
                                <p>Curabitur venenatis efficitur lorem sed tempor. Integer aliquet tempor cursus. Nullam vestibulum convallis risus vel condimentum. Nullam auctor lorem in libero luctus, vel volutpat quam tincidunt. Morbi sodales, dolor id ultricies dictum, diam odio tempor purus, at ultrices elit nulla ac nisl. Vestibulum enim sapien, blandit finibus elit vitae, venenatis tempor enim. </p>
                            </div><!-- .tab-content -->
                        </div><!-- .tabs-container -->
                    </div><!-- .tabs -->
                </div><!-- .col-12 -->
            </div><!-- .row -->
       
	   </div><!-- container -->
    </div><!-- main-content -->
</div><!-- main-content -->
	