<?php //session_start(); ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Sunfest !</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo css_url('bootstrap.min') ?>">
    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="<?php echo css_url('fontawesome-all.min') ?>">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php echo css_url('swiper.min') ?>">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo css_url('style.min') ?>">
	
    <link rel="stylesheet" href="<?php echo css_url('css-sprites.min') ?>">
</head>

<body>
    <header class="site-header">
        <div class="header-bar" style="<?php if(isset($page)) { echo "margin-top: 0px; position: fixed; background-color: black; height: 30px"; }?>">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-10 col-lg-4">
                        <h1 class="site-branding flex">
                            <a href="#">SUNFEST</a>
                        </h1>
                    </div>

                    <div class="col-2 col-lg-8">
                        <nav class="site-navigation">
                            <div class="hamburger-menu d-lg-none">
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                            </div><!-- .hamburger-menu -->

                            <ul>
                                <li><a href="<?php echo site_url('/') ;?>">HOME</a></li>
                                <li><a href="<?php echo site_url('artists') ?>">ARTISTS</a></li>
                                <li><a href="<?php echo site_url('events') ;?>">EVENT</a></li>
								<?php if( ! isset($_SESSION['artiste'])) {?>
                                <li><a href="<?php echo site_url('login') ;?>">LOG IN</a></li>
                                <li><a href="<?php echo site_url('register') ;?>">REGISTER</a></li>
								<?php } else {?>
                                <li><a href="<?php echo site_url('account') ?>">ACCOUNT</a></li>
                                <li><a href="<?php echo site_url('logout') ;?>">LOG OUT</a></li>
								<?php } ?>
                                <li><a href="#"><i class="fas fa-search"></i></a></li>
                            </ul><!-- flex -->
                        </nav><!-- .site-navigation -->
                    </div><!-- .col-12 -->
                </div><!-- .row -->
            </div><!-- container-fluid -->
        </div><!-- header-bar -->
    </header><!-- .site-header -->
	<?php if(!isset($page)) {?>
    <div class="hero-content">
        <div class="container">
            <div class="row">
                <div class="col-12 offset-lg-2 col-lg-10">
                    <div class="entry-header">
                        <h1>Sunfest !</h1>
                    </div><!-- .entry-header -->
                </div><!-- .col-12 -->
            </div><!-- row -->
        </div><!-- .container -->
    </div><!-- .hero-content -->
	<?php }?>
    
    
	<?php 
		if(isset($page)) {
			include($page.".php");
		} else {
			include('acceuil.php');
		}
	?>
    

    <footer class="site-footer">
        <div class="footer-cover-title flex justify-content-center align-items-center">
            <h2>SUNFEST</h2>
        </div><!-- .site-footer -->

        <div class="footer-content-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="entry-title">
                            <a href="#">SUNFEST</a>
                        </div><!-- entry-title -->

                        <div class="entry-mail">
                            <a href="#">MANANDRAIBE	Johnatan n°60</a>
                        </div><!-- .entry-mail -->

                        <div class="copyright-info">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by MANANDRAIBE Johnatan n° 60
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </div><!-- copyright-info -->

                        <div class="footer-social">
                            <ul class="flex justify-content-center align-items-center">
                                <li><a href="#" class="fb"></a></li>
                                <li><a href="#" class="google"></a></li>
                                <li><a href="#" class="linkedin"></a></li>
                                <li><a href="#" class="twiter"></a></li>
								
                                <!--<li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-dribbble"></i></a></li>
                                <li><a href="#"><i class="fab fa-behance"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>-->
                            </ul>
                        </div><!-- footer-social -->
                    </div><!-- col -->
                </div><!-- row -->
            </div><!-- container -->
        </div><!-- footer-content-wrapper -->
    </footer><!-- site-footer -->

    <script type='text/javascript' src='<?php echo js_url('jquery') ?>'></script>
    <script type='text/javascript' src='<?php echo js_url('masonry.pkgd.min') ?>'></script>
    <script type='text/javascript' src='<?php echo js_url('jquery.collapsible.min') ?>'></script>
    <script type='text/javascript' src='<?php echo js_url('swiper.min') ?>'></script>
    <script type='text/javascript' src='<?php echo js_url('jquery.countdown.min') ?>'></script>
    <script type='text/javascript' src='<?php echo js_url('circle-progress.min') ?>'></script>
    <script type='text/javascript' src='<?php echo js_url('jquery.countTo.min') ?>'></script>
    <script type='text/javascript' src='<?php echo js_url('custom') ?>'></script>
</body>
</html>
