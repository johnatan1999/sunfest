<!DOCTYPE html>
<!--
* CoreUI - Free Bootstrap Admin Template
* @version v2.1.8
* @link https://coreui.io
* Copyright (c) 2018 creativeLabs Łukasz Holeczek
* Licensed under MIT (https://coreui.io/license)
-->

<html lang="en">
	<head>
		<base href="./">
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
		<meta name="description" content="CoreUI - Open Source Bootstrap Admin Template">
		<meta name="author" content="Łukasz Holeczek">
		<meta name="keyword" content="Artist, Login, Artist login">
		<title>Artist login</title>

		<!-- Main styles for this application-->
		<link href="<?php echo css_url('style') ?>" rel="stylesheet">
		<link href="<?php echo css_url('bootstrap') ?>" rel="stylesheet">
	</head>
	<body class="app flex-row align-items-center" style="background: url(<?php echo img_url('cover.jpg')?>)">
	
				<div class="container-fluid" style="padding: 2%">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="back-link back-backend">
								<a href="<?php echo site_url('/') ?>" class="btn btn-danger">Back to home</a>
							</div>
						</div>
					</div>
				</div>
				<div class="container-fluid" style="margin-top: 8%">
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12"></div>
						<div class="col-md-4 col-md-4 col-sm-4 col-xs-12" style="color: white">
							<div class="text-center m-b-md custom-login">
								<h3>LOGIN</h3>
							</div>
							<div class="hpanel">
								<div class="panel-body">
									<form action="<?php echo site_url('authentification') ?>" id="loginForm" method="post">
										<div class="form-group">
											<label class="control-label" for="username">Username</label>
											<input type="text" placeholder="example@gmail.com" title="Please enter you username" required="" value="" name="username" id="username" class="form-control">
										</div>
										<div class="form-group">
											<label class="control-label" for="password">Password</label>
											<input type="password" title="Please enter your password" placeholder="******" required="" value="" name="password" id="password" class="form-control">
										</div>
										<div class="checkbox login-checkbox">
											<label style="color: red" > <?php if(isset($error)) { echo $error; } ?></label>
										</div>
										<button type="submit" class="btn btn-success btn-block loginbtn">Login</button>
										<a class="btn btn-default btn-block" href="<?php echo site_url('register') ?>">Register</a>
									</form>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12"></div>
					</div>
					<div class="row">
						<div class="col-md-12 col-md-12 col-sm-12 col-xs-12 text-center">
						</div>
					</div>
				</div>
	
	</body>
</html>
