<!DOCTYPE html>
<!--
* CoreUI - Free Bootstrap Admin Template
* @version v2.1.8
* @link https://coreui.io
* Copyright (c) 2018 creativeLabs Łukasz Holeczek
* Licensed under MIT (https://coreui.io/license)
-->

<html lang="en">
	<head>
		<base href="./">
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
		<meta name="description" content="CoreUI - Open Source Bootstrap Admin Template">
		<meta name="author" content="Łukasz Holeczek">
		<meta name="keyword" content="Artist, Login, Artist login">
		<title>Artist registration</title>

		<!-- Main styles for this application-->
		<link href="<?php echo css_url('style') ?>" rel="stylesheet">
		<link href="<?php echo css_url('bootstrap') ?>" rel="stylesheet">
	</head>
	<body class="app flex-row align-items-center" style="background: url(<?php echo img_url('cover.jpg')?>)">
	
				<div class="container-fluid" style="padding: 2%">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="back-link back-backend">
								<a href="<?php echo site_url('/') ?>" class="btn btn-danger">Back to home</a>
							</div>
						</div>
					</div>
				</div>
				<div class="container-fluid" style="margin-top: 8%">
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12"></div>
						<div class="col-md-4 col-md-4 col-sm-4 col-xs-12" style="color: white">
							<div class="text-center m-b-md custom-login">
								<h3>Registration</h3>
							</div>
							<div class="hpanel">
								<div class="panel-body">
									<form action="<?php echo site_url('registration') ;?>" id="loginForm" method="post">
										<div class="row">
											<div class="form-group col-lg-12">
												<label>Username</label>
												<input class="form-control" name="username">
											</div>
											<div class="form-group col-lg-12">
												<label>Artist name</label>
												<input type="text" name="name" class="form-control">
											</div>
											<div class="form-group col-lg-6">
												<label>Password</label>
												<input type="password" name="password" class="form-control">
											</div>
											<div class="form-group col-lg-6">
												<label>Repeat Password</label>
												<input type="password" name="confirmation" class="form-control">
											</div>
											<div class="checkbox col-lg-12">
											</div>
										</div>
										<div class="text-center">
											<button class="btn btn-success loginbtn">Register</button>
											<button class="btn btn-default">Cancel</button>
										</div>
										<a class="btn btn-default btn-block" href="<?php echo site_url('login') ?>">I have an account.</a>
									</form>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12"></div>
					</div>
					<div class="row">
						<div class="col-md-12 col-md-12 col-sm-12 col-xs-12 text-center">
						</div>
					</div>
				</div>
	
	</body>
</html>
